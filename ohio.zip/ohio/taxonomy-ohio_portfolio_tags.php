<?php
get_template_part( 'taxonomy', 'ohio_portfolio_category' );