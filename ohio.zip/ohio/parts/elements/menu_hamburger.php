<button class="icon-button hamburger" aria-controls="site-navigation" aria-expanded="false">
    <i class="icon"></i>
</button>